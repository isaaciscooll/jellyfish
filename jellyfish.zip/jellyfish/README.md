# jellyfish
literally a shitty chatapp i made
if you steal it and pull a streamlabs ill cry
anyways pls help me with this if u want x
<3
-isaac
